import ManagementContent from "@/components/ManagementContent";

export default function ManagementPage() {
  return <ManagementContent />;
}
