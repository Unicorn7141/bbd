import "@/app/globals.css";
import Sidebar from "@/components/Sidebar";
import { DataProvider } from "@/components/context/DataContext";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" dir="rtl">
      <title>Big Brother Dashboard</title>
      <body className="bg-[#0f1624] text-white flex">
        <DataProvider>
          <Sidebar />
          <main className="flex-1 p-6 overflow-y-auto">{children}</main>
        </DataProvider>
      </body>
    </html>
  );
}
