import DashboardContent from "@/components/DashboardContent";

export default function DashboardPage() {
  return <DashboardContent />;
}
