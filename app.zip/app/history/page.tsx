export default async function HistoryPage() {
  return <h1>History</h1>;
}
