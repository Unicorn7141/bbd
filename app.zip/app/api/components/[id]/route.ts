import { NextRequest, NextResponse } from "next/server";
import { pool } from "@/lib/db";

interface Params {
  params: { id: string };
}

export async function PUT(req: NextRequest, { params }: Params) {
  const id = params.id;
  const body = await req.json();

  const updatedFields = body.updatedFields || {};
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // 1. Load old component
    const existing = await client.query(
      `
      SELECT 
        id,
        serial_number AS "serialNumber",
        type,
        date_received AS "dateReceived",
        arrived_from AS "arrivedFrom",
        primary_fault AS "primaryFault",
        secondary_fault AS "secondaryFault",
        update_date AS "updateDate",
        status
      FROM components
      WHERE id = $1
      `,
      [id]
    );

    if (existing.rows.length === 0) {
      await client.query("ROLLBACK");
      return new NextResponse("NOT FOUND", { status: 404 });
    }

    const old = existing.rows[0];

    // Mapping JS → SQL columns
    const map: Record<string, string> = {
      serialNumber: "serial_number",
      type: "type",
      dateReceived: "date_received",
      arrivedFrom: "arrived_from",
      primaryFault: "primary_fault",
      secondaryFault: "secondary_fault",
      status: "status",
    };

    // Find changed fields
    const apply: any = {};
    const changes: any = {};

    for (const key in updatedFields) {
      if (!map[key]) continue;

      if (old[key] !== updatedFields[key]) {
        apply[map[key]] = updatedFields[key];
        changes[key] = { old: old[key], new: updatedFields[key] };
      }
    }

    if (Object.keys(apply).length === 0) {
      await client.query("ROLLBACK");
      return NextResponse.json(old);
    }

    // Build dynamic SQL
    let i = 1;
    const fields = [];
    const values: any[] = [];

    for (const col in apply) {
      fields.push(`${col} = $${i++}`);
      values.push(apply[col]);
    }

    const now = new Date().toISOString();
    fields.push(`update_date = $${i}`);
    values.push(now);

    values.push(id);

    const sql = `
      UPDATE components
      SET ${fields.join(", ")}
      WHERE id = $${i + 1}
      RETURNING 
        id,
        serial_number AS "serialNumber",
        type,
        date_received AS "dateReceived",
        arrived_from AS "arrivedFrom",
        primary_fault AS "primaryFault",
        secondary_fault AS "secondaryFault",
        update_date AS "updateDate",
        status
    `;

    const updated = await client.query(sql, values);

    // Insert history
    const versionRes = await client.query(
      `SELECT COALESCE(MAX(version), 0) + 1 AS v FROM component_history WHERE component_id = $1`,
      [id]
    );

    const version = versionRes.rows[0].v;

    await client.query(
      `INSERT INTO component_history 
      (component_id, version, timestamp, updated_by, changes, full_state)
      VALUES ($1,$2,$3,$4,$5,$6)`,
      [id, version, now, "מערכת", changes, updated.rows[0]]
    );

    await client.query("COMMIT");

    return NextResponse.json(updated.rows[0]);
  } catch (err) {
    await client.query("ROLLBACK");
    return new NextResponse("ERROR", { status: 500 });
  } finally {
    client.release();
  }
}
